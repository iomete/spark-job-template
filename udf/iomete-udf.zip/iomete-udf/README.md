# IOMETE UDF Extension

A Spark SQL extension that enables declarative, JSON-based registration of custom SQL User-Defined Functions (UDFs). Define UDFs as SQL subqueries in a JSON file and they are automatically registered when the SparkSession starts.

## How It Works

1. UDFs are defined in `src/main/resources/udfs.json`
2. On SparkSession startup, the extension reads the JSON definitions
3. Each UDF is registered as a Spark SQL function backed by a scalar subquery
4. Parameters are substituted into the SQL body at call time

## UDF Definition Format

UDFs are defined in `udfs.json` as an array of objects:

```json
[
  {
    "name": "udf_dell_fiscal_year",
    "description": "Dell fiscal year from corporate calendar",
    "parameters": ["input_date"],
    "body": "SELECT MAX(Fisc_yr_val) FROM eds_it_dev.comn_base.corp_cldr WHERE cldr_date = input_date"
  }
]
```

| Field         | Description                                                       |
|---------------|-------------------------------------------------------------------|
| `name`        | SQL function name used in queries                                 |
| `description` | Human-readable description                                        |
| `parameters`  | Parameter names referenced in the body                            |
| `body`        | SQL subquery body — parameter names are replaced with actual args |

## Building

Requires Maven and JDK 11+.

```bash
make build     # Compile
make test      # Run tests
make package   # Build shaded JAR
make clean     # Clean build artifacts
```

The shaded JAR is output to `target/iomete-udf-0.1.0.jar`. It bundles Jackson dependencies; Scala and Spark are expected to be provided at runtime.

## Usage

### IOMETE Setup

When creating a Job or Compute cluster in IOMETE, add the following configs:

- **Spark Configuration:** `spark.sql.extensions = com.iomete.udf.UDFExtension`
- **Jar Files:** Upload the shaded JAR to an accessible location on ECS and reference it in Dependencies

### Call UDFs in SQL

Once registered, UDFs are available in any Spark SQL query:

```sql
SELECT udf_dell_fiscal_year(DATE '2025-01-15') AS fiscal_year;

SELECT order_id, udf_dell_fiscal_year(order_date) AS fiscal_year
FROM orders;
```

## Adding New UDFs

Add a new entry to `src/main/resources/udfs.json`:

```json
{
  "name": "my_new_udf",
  "description": "Description of the function",
  "parameters": ["param1", "param2"],
  "body": "SELECT some_col FROM some_table WHERE col1 = param1 AND col2 = param2"
}
```

Rebuild and redeploy the JAR. No Scala code changes required.

## Project Structure

```
src/main/scala/com/iomete/udf/
├── UDFExtension.scala    # Spark extension entry point
├── UDFDefinition.scala   # UDF data model and JSON loading
└── SQLUDFBuilder.scala   # Builds Catalyst expressions from definitions

src/main/resources/
└── udfs.json             # Production UDF definitions

src/test/
├── scala/com/iomete/udf/UDFExtensionTest.scala
└── resources/udfs.json   # Test UDF definitions
```

## Tech Stack

- Scala 2.12 / Apache Spark 3.5
- Jackson for JSON parsing
- Maven with shade plugin for packaging