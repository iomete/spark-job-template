package com.iomete.udf

import org.apache.spark.sql.SparkSession
import org.scalatest.BeforeAndAfterAll
import org.scalatest.funsuite.AnyFunSuite

class UDFExtensionTest extends AnyFunSuite with BeforeAndAfterAll {

  var spark: SparkSession = _

  override def beforeAll(): Unit = {
    spark = SparkSession.builder()
      .master("local[*]")
      .appName("UDFExtensionTest")
      .config("spark.sql.extensions", classOf[UDFExtension].getCanonicalName)
      .getOrCreate()

    spark.sql(
      """
        |CREATE OR REPLACE TEMP VIEW corp_cldr AS
        |SELECT DATE '2025-01-15' AS cldr_date, 2025 AS Fisc_yr_val
        |UNION ALL
        |SELECT DATE '2024-06-01' AS cldr_date, 2024 AS Fisc_yr_val
        |UNION ALL
        |SELECT DATE '2023-12-31' AS cldr_date, 2024 AS Fisc_yr_val
      """.stripMargin)
  }

  override def afterAll(): Unit = {
    if (spark != null) {
      spark.stop()
    }
  }

  test("udf_dell_fiscal_year returns correct fiscal year") {
    val result = spark.sql("SELECT udf_dell_fiscal_year(DATE '2025-01-15') AS fy").collect()
    assert(result.length == 1)
    assert(result(0).getInt(0) == 2025)
  }

  test("udf_dell_fiscal_year works with different dates") {
    val result = spark.sql("SELECT udf_dell_fiscal_year(DATE '2024-06-01') AS fy").collect()
    assert(result.length == 1)
    assert(result(0).getInt(0) == 2024)
  }

  test("udf_dell_fiscal_year works with column reference") {
    spark.sql(
      """
        |CREATE OR REPLACE TEMP VIEW employees AS
        |SELECT 'Alice' AS name, DATE '2025-01-15' AS hire_date
        |UNION ALL
        |SELECT 'Bob' AS name, DATE '2024-06-01' AS hire_date
      """.stripMargin)

    val result = spark.sql(
      "SELECT name, udf_dell_fiscal_year(hire_date) AS fy FROM employees ORDER BY name"
    ).collect()

    assert(result.length == 2)
    assert(result(0).getString(0) == "Alice")
    assert(result(0).getInt(1) == 2025)
    assert(result(1).getString(0) == "Bob")
    assert(result(1).getInt(1) == 2024)
  }

  test("UDF is visible in function registry") {
    val functions = spark.sql("SHOW FUNCTIONS").collect().map(_.getString(0))
    assert(functions.contains("udf_dell_fiscal_year"))
  }
}
