package com.iomete.udf

import com.fasterxml.jackson.databind.ObjectMapper
import com.fasterxml.jackson.module.scala.DefaultScalaModule

case class UDFDefinition(
    name: String,
    description: String,
    parameters: List[String],
    body: String
)

object UDFDefinition {
  private val mapper = new ObjectMapper()
  mapper.registerModule(DefaultScalaModule)

  def load(): List[UDFDefinition] = {
    val stream = getClass.getClassLoader.getResourceAsStream("udfs.json")
    if (stream == null) {
      throw new RuntimeException("udfs.json not found on classpath")
    }
    try {
      mapper.readValue(
        stream,
        mapper.getTypeFactory.constructCollectionType(classOf[java.util.List[_]], classOf[UDFDefinition])
      ).asInstanceOf[java.util.List[UDFDefinition]].toArray.toList.asInstanceOf[List[UDFDefinition]]
    } finally {
      stream.close()
    }
  }
}
