package com.iomete.udf

import org.apache.spark.sql.SparkSession
import org.apache.spark.sql.catalyst.FunctionIdentifier
import org.apache.spark.sql.catalyst.analysis.UnresolvedAttribute
import org.apache.spark.sql.catalyst.expressions.{Expression, ExpressionInfo, ScalarSubquery}

object SQLUDFBuilder {

  type FunctionDescription = (FunctionIdentifier, ExpressionInfo, Seq[Expression] => Expression)

  def build(udf: UDFDefinition): FunctionDescription = {
    val identifier = FunctionIdentifier(udf.name)

    val info = new ExpressionInfo(
      classOf[ScalarSubquery].getCanonicalName,
      null,
      udf.name,
      udf.description,
      "",
      "",
      "",
      "",
      "",
      "",
      "built-in"
    )

    val builder: Seq[Expression] => Expression = (args: Seq[Expression]) => {
      val session = SparkSession.getActiveSession.getOrElse(
        throw new RuntimeException("No active SparkSession found")
      )

      val paramMap = udf.parameters.zip(args).toMap

      var sqlBody = udf.body
      paramMap.foreach { case (param, expr) =>
        sqlBody = sqlBody.replace(param, expr.sql)
      }

      val subqueryExpr = session.sessionState.sqlParser.parseExpression(s"($sqlBody)")
      subqueryExpr
    }

    (identifier, info, builder)
  }
}
