package com.iomete.udf

import org.apache.spark.sql.SparkSessionExtensions

class UDFExtension extends (SparkSessionExtensions => Unit) {
  override def apply(extensions: SparkSessionExtensions): Unit = {
    UDFDefinition.load().foreach { udf =>
      extensions.injectFunction(SQLUDFBuilder.build(udf))
    }
  }
}
